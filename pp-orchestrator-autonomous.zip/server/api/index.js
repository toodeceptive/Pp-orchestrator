import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import bodyParser from 'body-parser'
import path from 'path'
import { fileURLToPath } from 'url'
import { cfg } from './config/env.js'
import { query } from './db/index.js'
import { orchestrate } from './core/kernel.js'
import oauthRouter from './interfaces/oauth.js'
import pushRouter from './interfaces/push.js'
import pushPublic from './interfaces/push.public.js'
import webhooksRouter from './interfaces/webhooks.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const app = express()
app.use(cors())
app.use(bodyParser.json({ limit:'2mb' }))

// Static PWA
app.use('/', express.static(path.resolve(__dirname, '../web')))

app.get('/healthz', (req,res)=> res.json({ ok:true, ts: new Date().toISOString() }))

app.post('/execute', async (req,res)=>{
  const input = String(req.body?.input || '').trim()
  if (!input) return res.status(400).json({ error:'input required' })
  const out = await orchestrate({ task: input })
  res.json(out)
})

app.get('/confirm', async (req,res)=>{
  const t = String(req.query.token||'')
  if (!t) return res.status(400).send('token required')
  const r = await query('SELECT * FROM confirmations WHERE token=$1 AND used_at IS NULL', [t])
  if (!r.rowCount) return res.status(400).send('invalid or used token')
  const c = r.rows[0]
  await query('UPDATE confirmations SET used_at=now() WHERE id=$1', [c.id])
  await query('UPDATE runs SET status=$1 WHERE id=$2', ['approved', c.run_id])
  // enqueue job for worker
  const { q } = await import('./queue/index.js')
  await q.enqueue('execute', { run_id: c.run_id })
  res.send('<h1>Approved</h1><p>Job resumed.</p>')
})

app.use('/oauth', oauthRouter)
app.use('/push', pushPublic)
app.use('/push', pushRouter)
app.use('/webhooks', webhooksRouter)

// Run migrations on boot (simple, idempotent for demo)
import './db/migrate.js'

const PORT = process.env.PORT || 8789
app.listen(PORT, ()=> console.log('API listening on', PORT))
