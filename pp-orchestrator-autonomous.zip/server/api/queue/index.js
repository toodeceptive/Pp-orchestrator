import { createClient } from 'redis'
import { cfg } from '../config/env.js'
const client = createClient({ url: cfg().redis.url })
client.on('error', err => console.error('Redis error', err))
await client.connect()
export const q = {
  async enqueue(type, payload) {
    const job = JSON.stringify({ type, payload, enqueuedAt: Date.now() })
    await client.lPush('pp:jobs', job)
    return true
  },
  async bpop(timeout=0) {
    const res = await client.brPop('pp:jobs', timeout)
    if (!res) return null
    return JSON.parse(res.element)
  }
}
