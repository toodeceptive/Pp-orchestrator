import 'dotenv/config'
import { q } from './queue/index.js'
import { query } from './db/index.js'
import { execute } from './runner.js'

console.log('Worker started')
while (true) {
  const job = await q.bpop(0)
  if (!job) continue
  try {
    if (job.type === 'execute') {
      const run_id = job.payload.run_id
      await query('UPDATE runs SET status=$1 WHERE id=$2', ['running', run_id])
      const res = await execute({ run_id })
      await query('UPDATE runs SET status=$1, finished_at=now() WHERE id=$2', [res.ok?'done':'error', run_id])
    } else if (job.type === 'webhook') {
      // For later: transform webhook events into runs or updates
      await query('INSERT INTO audits(run_id, stage, data) VALUES ($1,$2,$3)', [null, 'webhook', job.payload])
    }
  } catch (e) {
    console.error('Worker error', e)
  }
}
